﻿## In Depth  
Multiplication of values send to the input ports.  
E.g. item0 = 9, item0 = 2.3, result = 20.7.  
  
More ports can be added by pushing the plus sign in the node or removing ports by pushing the minus sign in the node.
  
**Example**  
![Illustration](./Orchid.Common.Math.Multiplication.png)
**WebSite**  
[Github](https://github.com/erfajo/OrchidForDynamo) -- [Issues](https://github.com/erfajo/OrchidForDynamo/issues) -- [Samples](https://github.com/erfajo/OrchidForDynamo/tree/master/Samples) -- [Blog](https://erfajo.blogspot.com)
