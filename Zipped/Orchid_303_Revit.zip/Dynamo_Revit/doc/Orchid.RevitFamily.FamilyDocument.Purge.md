﻿## In Depth  
Purge family document.  
If input port "completely" is set to true, does purge include the functions from following nodes:  
- LineStyle.Purge
- Category.DeleteImported
- Material.Purge
- Asset.Purge 
  
**Example**  
![Illustration](./Orchid.RevitFamily.FamilyDocument.Purge.png)
**WebSite**  
[Github](https://github.com/erfajo/OrchidForDynamo) -- [Issues](https://github.com/erfajo/OrchidForDynamo/issues) -- [Samples](https://github.com/erfajo/OrchidForDynamo/tree/master/Samples) -- [Blog](https://erfajo.blogspot.com)
