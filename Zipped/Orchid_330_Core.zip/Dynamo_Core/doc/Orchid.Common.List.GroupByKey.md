﻿## In Depth  
Group items into sublists based on the list of key values. The result may be reversed as descending by the key values.  

**Example**  
![Illustration](./Orchid.Common.List.GroupByKey.png)  
**WebSite**  
[Github](https://github.com/erfajo/OrchidForDynamo) -- [Issues](https://github.com/erfajo/OrchidForDynamo/issues) -- [Samples](https://github.com/erfajo/OrchidForDynamo/tree/master/Samples) -- [Blog](https://erfajo.blogspot.com)
