﻿## In Depth  
Determines if all items in the given list has a true value.  

**Example**  
![Illustration](./Orchid.Common.List.AllTrue.png)
**WebSite**  
[Github](https://github.com/erfajo/OrchidForDynamo) -- [Issues](https://github.com/erfajo/OrchidForDynamo/issues) -- [Samples](https://github.com/erfajo/OrchidForDynamo/tree/master/Samples) -- [Blog](https://erfajo.blogspot.com)
