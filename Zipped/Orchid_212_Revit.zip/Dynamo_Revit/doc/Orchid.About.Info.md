﻿## In Depth  
In-depth description is under construction, however, until then please visit [OrchidForDynamo](https://github.com/erfajo/OrchidForDynamo) at github for assistance, especially try to see the [sample](https://github.com/erfajo/OrchidForDynamo/tree/master/Samples) collection for inspiration.

**WebSite**  
[Github](https://github.com/erfajo/OrchidForDynamo) -- [Issues](https://github.com/erfajo/OrchidForDynamo/issues) -- [Samples](https://github.com/erfajo/OrchidForDynamo/tree/master/Samples) -- [Blog](https://erfajo.blogspot.com)
